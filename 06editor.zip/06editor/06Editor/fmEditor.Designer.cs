﻿namespace _06Editor {
    partial class fmEditor {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent() {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(fmEditor));
            this.tsBarraEstandar = new System.Windows.Forms.ToolStrip();
            this.cmnBarras = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.itcBarraEstandar = new System.Windows.Forms.ToolStripMenuItem();
            this.itcBarraFormato = new System.Windows.Forms.ToolStripMenuItem();
            this.itcBarraEstado = new System.Windows.Forms.ToolStripMenuItem();
            this.tsbNuevo = new System.Windows.Forms.ToolStripButton();
            this.tsbAbrir = new System.Windows.Forms.ToolStripButton();
            this.tsbGuardar = new System.Windows.Forms.ToolStripButton();
            this.tsbImprimir = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbCortar = new System.Windows.Forms.ToolStripButton();
            this.tsbCopiar = new System.Windows.Forms.ToolStripButton();
            this.tsbPegar = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbDeshacer = new System.Windows.Forms.ToolStripButton();
            this.tsbRehacer = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbCopiarFormato = new System.Windows.Forms.ToolStripButton();
            this.tsbQuitarFormato = new System.Windows.Forms.ToolStripButton();
            this.tsBarraFormato = new System.Windows.Forms.ToolStrip();
            this.tsbNegrita = new System.Windows.Forms.ToolStripButton();
            this.tsbCursiva = new System.Windows.Forms.ToolStripButton();
            this.tsbSubrayado = new System.Windows.Forms.ToolStripButton();
            this.tsbTachado = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbIzq = new System.Windows.Forms.ToolStripButton();
            this.tsbCentrado = new System.Windows.Forms.ToolStripButton();
            this.tsbDer = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.cbxFuente = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
            this.cbxTamanyo = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripSeparator9 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbColores = new System.Windows.Forms.ToolStripButton();
            this.stEstadoEditor = new System.Windows.Forms.StatusStrip();
            this.sl1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.sl2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.sl3 = new System.Windows.Forms.ToolStripStatusLabel();
            this.sl4 = new System.Windows.Forms.ToolStripStatusLabel();
            this.sl5 = new System.Windows.Forms.ToolStripStatusLabel();
            this.mnEditor = new System.Windows.Forms.MenuStrip();
            this.archivoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.itNuevo = new System.Windows.Forms.ToolStripMenuItem();
            this.itAbrir = new System.Windows.Forms.ToolStripMenuItem();
            this.itGuardar = new System.Windows.Forms.ToolStripMenuItem();
            this.itGuardarComo = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.itImprimir = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.itSalir = new System.Windows.Forms.ToolStripMenuItem();
            this.ediciónToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.itDeshacer = new System.Windows.Forms.ToolStripMenuItem();
            this.itRehacer = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripSeparator();
            this.itCortar = new System.Windows.Forms.ToolStripMenuItem();
            this.itCopiar = new System.Windows.Forms.ToolStripMenuItem();
            this.itPegar = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripSeparator();
            this.itBorrar = new System.Windows.Forms.ToolStripMenuItem();
            this.itSeleccionarTodo = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripSeparator();
            this.itIrA = new System.Windows.Forms.ToolStripMenuItem();
            this.formatoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.itFuentes = new System.Windows.Forms.ToolStripMenuItem();
            this.itColorFondo = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem6 = new System.Windows.Forms.ToolStripSeparator();
            this.itMargenes = new System.Windows.Forms.ToolStripMenuItem();
            this.itAlineaciones = new System.Windows.Forms.ToolStripMenuItem();
            this.itIzq = new System.Windows.Forms.ToolStripMenuItem();
            this.itCentrado = new System.Windows.Forms.ToolStripMenuItem();
            this.itDer = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem7 = new System.Windows.Forms.ToolStripSeparator();
            this.itVinyetas = new System.Windows.Forms.ToolStripMenuItem();
            this.itFormatoPagina = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem8 = new System.Windows.Forms.ToolStripSeparator();
            this.itQuitarFormatos = new System.Windows.Forms.ToolStripMenuItem();
            this.verToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.itBarraHerEstandar = new System.Windows.Forms.ToolStripMenuItem();
            this.itBarraHerFormato = new System.Windows.Forms.ToolStripMenuItem();
            this.itBarraEstado = new System.Windows.Forms.ToolStripMenuItem();
            this.ayudaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.itAcercaDe = new System.Windows.Forms.ToolStripMenuItem();
            this.itIndiceAyuda = new System.Windows.Forms.ToolStripMenuItem();
            this.itAyudaGeneral = new System.Windows.Forms.ToolStripMenuItem();
            this.rtbEditor = new System.Windows.Forms.RichTextBox();
            this.cmnEditor = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.cmnDeshacer = new System.Windows.Forms.ToolStripMenuItem();
            this.cmnRehacer = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.cmnCortar = new System.Windows.Forms.ToolStripMenuItem();
            this.cmnCopiar = new System.Windows.Forms.ToolStripMenuItem();
            this.cmnPegar = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.cmnBorrar = new System.Windows.Forms.ToolStripMenuItem();
            this.cmnSeleccionarTodo = new System.Windows.Forms.ToolStripMenuItem();
            this.timerEditor = new System.Windows.Forms.Timer(this.components);
            this.dlgGuardar = new System.Windows.Forms.SaveFileDialog();
            this.dlgAbrir = new System.Windows.Forms.OpenFileDialog();
            this.dlgImprimir = new System.Windows.Forms.PrintDialog();
            this.dlgColores = new System.Windows.Forms.ColorDialog();
            this.dlgFuentes = new System.Windows.Forms.FontDialog();
            this.tsBarraEstandar.SuspendLayout();
            this.cmnBarras.SuspendLayout();
            this.tsBarraFormato.SuspendLayout();
            this.stEstadoEditor.SuspendLayout();
            this.mnEditor.SuspendLayout();
            this.cmnEditor.SuspendLayout();
            this.SuspendLayout();
            // 
            // tsBarraEstandar
            // 
            this.tsBarraEstandar.ContextMenuStrip = this.cmnBarras;
            this.tsBarraEstandar.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.tsBarraEstandar.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbNuevo,
            this.tsbAbrir,
            this.tsbGuardar,
            this.tsbImprimir,
            this.toolStripSeparator1,
            this.tsbCortar,
            this.tsbCopiar,
            this.tsbPegar,
            this.toolStripSeparator2,
            this.tsbDeshacer,
            this.tsbRehacer,
            this.toolStripSeparator3,
            this.tsbCopiarFormato,
            this.tsbQuitarFormato});
            this.tsBarraEstandar.Location = new System.Drawing.Point(0, 30);
            this.tsBarraEstandar.Name = "tsBarraEstandar";
            this.tsBarraEstandar.Size = new System.Drawing.Size(1068, 31);
            this.tsBarraEstandar.TabIndex = 0;
            this.tsBarraEstandar.Text = "toolStrip1";
            // 
            // cmnBarras
            // 
            this.cmnBarras.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.cmnBarras.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.itcBarraEstandar,
            this.itcBarraFormato,
            this.itcBarraEstado});
            this.cmnBarras.Name = "cmnBarras";
            this.cmnBarras.Size = new System.Drawing.Size(286, 82);
            // 
            // itcBarraEstandar
            // 
            this.itcBarraEstandar.Checked = true;
            this.itcBarraEstandar.CheckState = System.Windows.Forms.CheckState.Checked;
            this.itcBarraEstandar.Name = "itcBarraEstandar";
            this.itcBarraEstandar.Size = new System.Drawing.Size(285, 26);
            this.itcBarraEstandar.Text = "Barra de herramientas Estandar";
            this.itcBarraEstandar.Click += new System.EventHandler(this.itBarraHerEstandar_Click);
            // 
            // itcBarraFormato
            // 
            this.itcBarraFormato.Checked = true;
            this.itcBarraFormato.CheckState = System.Windows.Forms.CheckState.Checked;
            this.itcBarraFormato.Name = "itcBarraFormato";
            this.itcBarraFormato.Size = new System.Drawing.Size(285, 26);
            this.itcBarraFormato.Text = "Barra de herramientas Formato";
            this.itcBarraFormato.Click += new System.EventHandler(this.itBarraHerFormato_Click);
            // 
            // itcBarraEstado
            // 
            this.itcBarraEstado.Checked = true;
            this.itcBarraEstado.CheckState = System.Windows.Forms.CheckState.Checked;
            this.itcBarraEstado.Name = "itcBarraEstado";
            this.itcBarraEstado.Size = new System.Drawing.Size(285, 26);
            this.itcBarraEstado.Text = "Barra de Estado";
            this.itcBarraEstado.Click += new System.EventHandler(this.itBarraEstado_Click);
            // 
            // tsbNuevo
            // 
            this.tsbNuevo.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbNuevo.Image = ((System.Drawing.Image)(resources.GetObject("tsbNuevo.Image")));
            this.tsbNuevo.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbNuevo.Name = "tsbNuevo";
            this.tsbNuevo.Size = new System.Drawing.Size(29, 28);
            this.tsbNuevo.Text = "Nuevo";
            this.tsbNuevo.Click += new System.EventHandler(this.ItNuevo_Click);
            // 
            // tsbAbrir
            // 
            this.tsbAbrir.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbAbrir.Image = ((System.Drawing.Image)(resources.GetObject("tsbAbrir.Image")));
            this.tsbAbrir.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbAbrir.Name = "tsbAbrir";
            this.tsbAbrir.Size = new System.Drawing.Size(29, 24);
            this.tsbAbrir.Text = "toolStripButton2";
            this.tsbAbrir.Click += new System.EventHandler(this.ItAbrir_Click);
            // 
            // tsbGuardar
            // 
            this.tsbGuardar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbGuardar.Image = global::_06Editor.Properties.Resources.saveHS;
            this.tsbGuardar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbGuardar.Name = "tsbGuardar";
            this.tsbGuardar.Size = new System.Drawing.Size(29, 24);
            this.tsbGuardar.Text = "toolStripButton3";
            this.tsbGuardar.Click += new System.EventHandler(this.ItGuardar_Click);
            // 
            // tsbImprimir
            // 
            this.tsbImprimir.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbImprimir.Image = ((System.Drawing.Image)(resources.GetObject("tsbImprimir.Image")));
            this.tsbImprimir.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbImprimir.Name = "tsbImprimir";
            this.tsbImprimir.Size = new System.Drawing.Size(29, 24);
            this.tsbImprimir.Text = "toolStripButton4";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 27);
            // 
            // tsbCortar
            // 
            this.tsbCortar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbCortar.Image = ((System.Drawing.Image)(resources.GetObject("tsbCortar.Image")));
            this.tsbCortar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbCortar.Name = "tsbCortar";
            this.tsbCortar.Size = new System.Drawing.Size(29, 24);
            this.tsbCortar.Text = "toolStripButton5";
            this.tsbCortar.Click += new System.EventHandler(this.tsbCortar_Click);
            // 
            // tsbCopiar
            // 
            this.tsbCopiar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbCopiar.Image = ((System.Drawing.Image)(resources.GetObject("tsbCopiar.Image")));
            this.tsbCopiar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbCopiar.Name = "tsbCopiar";
            this.tsbCopiar.Size = new System.Drawing.Size(29, 24);
            this.tsbCopiar.Text = "toolStripButton6";
            this.tsbCopiar.Click += new System.EventHandler(this.tsbCopiar_Click);
            // 
            // tsbPegar
            // 
            this.tsbPegar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbPegar.Image = ((System.Drawing.Image)(resources.GetObject("tsbPegar.Image")));
            this.tsbPegar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbPegar.Name = "tsbPegar";
            this.tsbPegar.Size = new System.Drawing.Size(29, 24);
            this.tsbPegar.Text = "toolStripButton7";
            this.tsbPegar.Click += new System.EventHandler(this.tsbPegar_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 27);
            // 
            // tsbDeshacer
            // 
            this.tsbDeshacer.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbDeshacer.Image = ((System.Drawing.Image)(resources.GetObject("tsbDeshacer.Image")));
            this.tsbDeshacer.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbDeshacer.Name = "tsbDeshacer";
            this.tsbDeshacer.Size = new System.Drawing.Size(29, 24);
            this.tsbDeshacer.Text = "toolStripButton8";
            this.tsbDeshacer.Click += new System.EventHandler(this.tsbDeshacer_Click);
            // 
            // tsbRehacer
            // 
            this.tsbRehacer.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbRehacer.Image = ((System.Drawing.Image)(resources.GetObject("tsbRehacer.Image")));
            this.tsbRehacer.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbRehacer.Name = "tsbRehacer";
            this.tsbRehacer.Size = new System.Drawing.Size(29, 24);
            this.tsbRehacer.Text = "toolStripButton9";
            this.tsbRehacer.Click += new System.EventHandler(this.tsbRehacer_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 27);
            // 
            // tsbCopiarFormato
            // 
            this.tsbCopiarFormato.CheckOnClick = true;
            this.tsbCopiarFormato.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbCopiarFormato.Image = ((System.Drawing.Image)(resources.GetObject("tsbCopiarFormato.Image")));
            this.tsbCopiarFormato.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbCopiarFormato.Name = "tsbCopiarFormato";
            this.tsbCopiarFormato.Size = new System.Drawing.Size(29, 24);
            this.tsbCopiarFormato.Text = "toolStripButton10";
            this.tsbCopiarFormato.Click += new System.EventHandler(this.tsbCopiarFormato_Click);
            // 
            // tsbQuitarFormato
            // 
            this.tsbQuitarFormato.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbQuitarFormato.Image = ((System.Drawing.Image)(resources.GetObject("tsbQuitarFormato.Image")));
            this.tsbQuitarFormato.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbQuitarFormato.Name = "tsbQuitarFormato";
            this.tsbQuitarFormato.Size = new System.Drawing.Size(29, 24);
            this.tsbQuitarFormato.Text = "toolStripButton11";
            this.tsbQuitarFormato.Click += new System.EventHandler(this.tsbQuitarFormato_Click);
            // 
            // tsBarraFormato
            // 
            this.tsBarraFormato.ContextMenuStrip = this.cmnBarras;
            this.tsBarraFormato.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.tsBarraFormato.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbNegrita,
            this.tsbCursiva,
            this.tsbSubrayado,
            this.tsbTachado,
            this.toolStripSeparator6,
            this.tsbIzq,
            this.tsbCentrado,
            this.tsbDer,
            this.toolStripSeparator7,
            this.cbxFuente,
            this.toolStripSeparator8,
            this.cbxTamanyo,
            this.toolStripSeparator9,
            this.tsbColores});
            this.tsBarraFormato.Location = new System.Drawing.Point(0, 61);
            this.tsBarraFormato.Name = "tsBarraFormato";
            this.tsBarraFormato.Size = new System.Drawing.Size(1068, 31);
            this.tsBarraFormato.TabIndex = 0;
            this.tsBarraFormato.Text = "toolStrip2";
            // 
            // tsbNegrita
            // 
            this.tsbNegrita.CheckOnClick = true;
            this.tsbNegrita.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbNegrita.Image = ((System.Drawing.Image)(resources.GetObject("tsbNegrita.Image")));
            this.tsbNegrita.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbNegrita.Name = "tsbNegrita";
            this.tsbNegrita.Size = new System.Drawing.Size(29, 25);
            this.tsbNegrita.Text = "toolStripButton13";
            this.tsbNegrita.Click += new System.EventHandler(this.TsbNegrita_Click);
            // 
            // tsbCursiva
            // 
            this.tsbCursiva.CheckOnClick = true;
            this.tsbCursiva.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbCursiva.Image = ((System.Drawing.Image)(resources.GetObject("tsbCursiva.Image")));
            this.tsbCursiva.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbCursiva.Name = "tsbCursiva";
            this.tsbCursiva.Size = new System.Drawing.Size(29, 25);
            this.tsbCursiva.Text = "toolStripButton14";
            this.tsbCursiva.Click += new System.EventHandler(this.TsbNegrita_Click);
            // 
            // tsbSubrayado
            // 
            this.tsbSubrayado.CheckOnClick = true;
            this.tsbSubrayado.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbSubrayado.Image = ((System.Drawing.Image)(resources.GetObject("tsbSubrayado.Image")));
            this.tsbSubrayado.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbSubrayado.Name = "tsbSubrayado";
            this.tsbSubrayado.Size = new System.Drawing.Size(29, 25);
            this.tsbSubrayado.Text = "toolStripButton15";
            this.tsbSubrayado.Click += new System.EventHandler(this.TsbNegrita_Click);
            // 
            // tsbTachado
            // 
            this.tsbTachado.CheckOnClick = true;
            this.tsbTachado.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbTachado.Image = ((System.Drawing.Image)(resources.GetObject("tsbTachado.Image")));
            this.tsbTachado.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbTachado.Name = "tsbTachado";
            this.tsbTachado.Size = new System.Drawing.Size(29, 25);
            this.tsbTachado.Text = "toolStripButton16";
            this.tsbTachado.Click += new System.EventHandler(this.TsbNegrita_Click);
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(6, 28);
            // 
            // tsbIzq
            // 
            this.tsbIzq.Checked = true;
            this.tsbIzq.CheckState = System.Windows.Forms.CheckState.Checked;
            this.tsbIzq.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbIzq.Image = ((System.Drawing.Image)(resources.GetObject("tsbIzq.Image")));
            this.tsbIzq.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbIzq.Name = "tsbIzq";
            this.tsbIzq.Size = new System.Drawing.Size(29, 25);
            this.tsbIzq.Text = "toolStripButton17";
            this.tsbIzq.Click += new System.EventHandler(this.TsbIzq_Click);
            // 
            // tsbCentrado
            // 
            this.tsbCentrado.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbCentrado.Image = ((System.Drawing.Image)(resources.GetObject("tsbCentrado.Image")));
            this.tsbCentrado.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbCentrado.Name = "tsbCentrado";
            this.tsbCentrado.Size = new System.Drawing.Size(29, 25);
            this.tsbCentrado.Text = "toolStripButton18";
            this.tsbCentrado.Click += new System.EventHandler(this.TsbCentrado_Click);
            // 
            // tsbDer
            // 
            this.tsbDer.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbDer.Image = ((System.Drawing.Image)(resources.GetObject("tsbDer.Image")));
            this.tsbDer.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbDer.Name = "tsbDer";
            this.tsbDer.Size = new System.Drawing.Size(29, 25);
            this.tsbDer.Text = "toolStripButton19";
            this.tsbDer.Click += new System.EventHandler(this.TsbDer_Click);
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(6, 28);
            // 
            // cbxFuente
            // 
            this.cbxFuente.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxFuente.Name = "cbxFuente";
            this.cbxFuente.Size = new System.Drawing.Size(121, 28);
            this.cbxFuente.SelectedIndexChanged += new System.EventHandler(this.CbxFuente_SelectedIndexChanged);
            // 
            // toolStripSeparator8
            // 
            this.toolStripSeparator8.Name = "toolStripSeparator8";
            this.toolStripSeparator8.Size = new System.Drawing.Size(6, 28);
            // 
            // cbxTamanyo
            // 
            this.cbxTamanyo.Name = "cbxTamanyo";
            this.cbxTamanyo.Size = new System.Drawing.Size(121, 28);
            this.cbxTamanyo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.CbxTamanyo_KeyPress);
            this.cbxTamanyo.TextChanged += new System.EventHandler(this.CbxTamanyo_TextChanged);
            // 
            // toolStripSeparator9
            // 
            this.toolStripSeparator9.Name = "toolStripSeparator9";
            this.toolStripSeparator9.Size = new System.Drawing.Size(6, 28);
            // 
            // tsbColores
            // 
            this.tsbColores.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbColores.Image = ((System.Drawing.Image)(resources.GetObject("tsbColores.Image")));
            this.tsbColores.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbColores.Name = "tsbColores";
            this.tsbColores.Size = new System.Drawing.Size(29, 25);
            this.tsbColores.Text = "toolStripButton20";
            this.tsbColores.Click += new System.EventHandler(this.tsbColores_Click);
            // 
            // stEstadoEditor
            // 
            this.stEstadoEditor.ContextMenuStrip = this.cmnBarras;
            this.stEstadoEditor.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.stEstadoEditor.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sl1,
            this.sl2,
            this.sl3,
            this.sl4,
            this.sl5});
            this.stEstadoEditor.Location = new System.Drawing.Point(0, 506);
            this.stEstadoEditor.Name = "stEstadoEditor";
            this.stEstadoEditor.Size = new System.Drawing.Size(1068, 30);
            this.stEstadoEditor.TabIndex = 0;
            this.stEstadoEditor.Text = "statusStrip1";
            // 
            // sl1
            // 
            this.sl1.AutoSize = false;
            this.sl1.BorderSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.Left;
            this.sl1.BorderStyle = System.Windows.Forms.Border3DStyle.RaisedOuter;
            this.sl1.Name = "sl1";
            this.sl1.Size = new System.Drawing.Size(155, 24);
            // 
            // sl2
            // 
            this.sl2.AutoSize = false;
            this.sl2.BorderSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.Left;
            this.sl2.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter;
            this.sl2.Name = "sl2";
            this.sl2.Size = new System.Drawing.Size(155, 24);
            // 
            // sl3
            // 
            this.sl3.AutoSize = false;
            this.sl3.BorderSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.Left;
            this.sl3.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter;
            this.sl3.Name = "sl3";
            this.sl3.Size = new System.Drawing.Size(155, 24);
            // 
            // sl4
            // 
            this.sl4.AutoSize = false;
            this.sl4.BorderSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.Left;
            this.sl4.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter;
            this.sl4.Name = "sl4";
            this.sl4.Size = new System.Drawing.Size(155, 24);
            // 
            // sl5
            // 
            this.sl5.AutoSize = false;
            this.sl5.BorderSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.Left;
            this.sl5.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter;
            this.sl5.Name = "sl5";
            this.sl5.Size = new System.Drawing.Size(155, 24);
            this.sl5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // mnEditor
            // 
            this.mnEditor.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.mnEditor.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.archivoToolStripMenuItem,
            this.ediciónToolStripMenuItem,
            this.formatoToolStripMenuItem,
            this.verToolStripMenuItem,
            this.ayudaToolStripMenuItem});
            this.mnEditor.Location = new System.Drawing.Point(0, 0);
            this.mnEditor.Name = "mnEditor";
            this.mnEditor.Size = new System.Drawing.Size(1068, 30);
            this.mnEditor.TabIndex = 1;
            this.mnEditor.Text = "menuStrip1";
            // 
            // archivoToolStripMenuItem
            // 
            this.archivoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.itNuevo,
            this.itAbrir,
            this.itGuardar,
            this.itGuardarComo,
            this.toolStripMenuItem1,
            this.itImprimir,
            this.toolStripMenuItem2,
            this.itSalir});
            this.archivoToolStripMenuItem.Name = "archivoToolStripMenuItem";
            this.archivoToolStripMenuItem.Size = new System.Drawing.Size(73, 24);
            this.archivoToolStripMenuItem.Text = "Archivo";
            // 
            // itNuevo
            // 
            this.itNuevo.Image = global::_06Editor.Properties.Resources.NewFile_6276_32;
            this.itNuevo.Name = "itNuevo";
            this.itNuevo.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.U)));
            this.itNuevo.Size = new System.Drawing.Size(197, 26);
            this.itNuevo.Text = "Nuevo";
            this.itNuevo.Click += new System.EventHandler(this.ItNuevo_Click);
            // 
            // itAbrir
            // 
            this.itAbrir.Image = global::_06Editor.Properties.Resources.OpenFile;
            this.itAbrir.Name = "itAbrir";
            this.itAbrir.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.A)));
            this.itAbrir.Size = new System.Drawing.Size(197, 26);
            this.itAbrir.Text = "Abrir";
            this.itAbrir.Click += new System.EventHandler(this.ItAbrir_Click);
            // 
            // itGuardar
            // 
            this.itGuardar.Image = global::_06Editor.Properties.Resources.saveHS;
            this.itGuardar.Name = "itGuardar";
            this.itGuardar.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.G)));
            this.itGuardar.Size = new System.Drawing.Size(197, 26);
            this.itGuardar.Text = "Guardar";
            this.itGuardar.Click += new System.EventHandler(this.ItGuardar_Click);
            // 
            // itGuardarComo
            // 
            this.itGuardarComo.Name = "itGuardarComo";
            this.itGuardarComo.Size = new System.Drawing.Size(197, 26);
            this.itGuardarComo.Text = "Guardar Como";
            this.itGuardarComo.Click += new System.EventHandler(this.ItGuardarComo_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(194, 6);
            // 
            // itImprimir
            // 
            this.itImprimir.Image = global::_06Editor.Properties.Resources.printer_16xLG;
            this.itImprimir.Name = "itImprimir";
            this.itImprimir.Size = new System.Drawing.Size(197, 26);
            this.itImprimir.Text = "Imprimir";
            this.itImprimir.Click += new System.EventHandler(this.itImprimir_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(194, 6);
            // 
            // itSalir
            // 
            this.itSalir.Name = "itSalir";
            this.itSalir.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Delete)));
            this.itSalir.Size = new System.Drawing.Size(197, 26);
            this.itSalir.Text = "Salir";
            // 
            // ediciónToolStripMenuItem
            // 
            this.ediciónToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.itDeshacer,
            this.itRehacer,
            this.toolStripMenuItem3,
            this.itCortar,
            this.itCopiar,
            this.itPegar,
            this.toolStripMenuItem4,
            this.itBorrar,
            this.itSeleccionarTodo,
            this.toolStripMenuItem5,
            this.itIrA});
            this.ediciónToolStripMenuItem.Name = "ediciónToolStripMenuItem";
            this.ediciónToolStripMenuItem.Size = new System.Drawing.Size(72, 24);
            this.ediciónToolStripMenuItem.Text = "Edición";
            // 
            // itDeshacer
            // 
            this.itDeshacer.Image = global::_06Editor.Properties.Resources.Arrow_UndoRevertRestore_16xLG_color;
            this.itDeshacer.Name = "itDeshacer";
            this.itDeshacer.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Z)));
            this.itDeshacer.Size = new System.Drawing.Size(206, 26);
            this.itDeshacer.Text = "Deshacer";
            this.itDeshacer.Click += new System.EventHandler(this.tsbDeshacer_Click);
            // 
            // itRehacer
            // 
            this.itRehacer.Image = global::_06Editor.Properties.Resources.Arrow_RedoRetry_16xLG_color;
            this.itRehacer.Name = "itRehacer";
            this.itRehacer.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Y)));
            this.itRehacer.Size = new System.Drawing.Size(206, 26);
            this.itRehacer.Text = "Rehacer";
            this.itRehacer.Click += new System.EventHandler(this.tsbRehacer_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(203, 6);
            // 
            // itCortar
            // 
            this.itCortar.Image = global::_06Editor.Properties.Resources.cut;
            this.itCortar.Name = "itCortar";
            this.itCortar.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.X)));
            this.itCortar.Size = new System.Drawing.Size(206, 26);
            this.itCortar.Text = "Cortar";
            this.itCortar.Click += new System.EventHandler(this.tsbCortar_Click);
            // 
            // itCopiar
            // 
            this.itCopiar.Image = global::_06Editor.Properties.Resources.copy;
            this.itCopiar.Name = "itCopiar";
            this.itCopiar.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.C)));
            this.itCopiar.Size = new System.Drawing.Size(206, 26);
            this.itCopiar.Text = "Copiar";
            this.itCopiar.Click += new System.EventHandler(this.tsbCopiar_Click);
            // 
            // itPegar
            // 
            this.itPegar.Image = global::_06Editor.Properties.Resources.Paste;
            this.itPegar.Name = "itPegar";
            this.itPegar.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.V)));
            this.itPegar.Size = new System.Drawing.Size(206, 26);
            this.itPegar.Text = "Pegar";
            this.itPegar.Click += new System.EventHandler(this.tsbPegar_Click);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(203, 6);
            // 
            // itBorrar
            // 
            this.itBorrar.Name = "itBorrar";
            this.itBorrar.ShortcutKeys = System.Windows.Forms.Keys.Delete;
            this.itBorrar.Size = new System.Drawing.Size(206, 26);
            this.itBorrar.Text = "Borrar";
            this.itBorrar.Click += new System.EventHandler(this.itBorrar_Click);
            // 
            // itSeleccionarTodo
            // 
            this.itSeleccionarTodo.Name = "itSeleccionarTodo";
            this.itSeleccionarTodo.Size = new System.Drawing.Size(206, 26);
            this.itSeleccionarTodo.Text = "Seleccionar Todo";
            this.itSeleccionarTodo.Click += new System.EventHandler(this.itSeleccionarTodo_Click);
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(203, 6);
            // 
            // itIrA
            // 
            this.itIrA.Name = "itIrA";
            this.itIrA.Size = new System.Drawing.Size(206, 26);
            this.itIrA.Text = "Ir a";
            this.itIrA.Click += new System.EventHandler(this.itIrA_Click);
            // 
            // formatoToolStripMenuItem
            // 
            this.formatoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.itFuentes,
            this.itColorFondo,
            this.toolStripMenuItem6,
            this.itMargenes,
            this.itAlineaciones,
            this.toolStripMenuItem7,
            this.itVinyetas,
            this.itFormatoPagina,
            this.toolStripMenuItem8,
            this.itQuitarFormatos});
            this.formatoToolStripMenuItem.Name = "formatoToolStripMenuItem";
            this.formatoToolStripMenuItem.Size = new System.Drawing.Size(79, 24);
            this.formatoToolStripMenuItem.Text = "Formato";
            // 
            // itFuentes
            // 
            this.itFuentes.Image = global::_06Editor.Properties.Resources.FontSize_5701;
            this.itFuentes.Name = "itFuentes";
            this.itFuentes.Size = new System.Drawing.Size(271, 26);
            this.itFuentes.Text = "Fuentes";
            this.itFuentes.Click += new System.EventHandler(this.itFuentes_Click);
            // 
            // itColorFondo
            // 
            this.itColorFondo.Image = global::_06Editor.Properties.Resources.Color_background_32x32;
            this.itColorFondo.Name = "itColorFondo";
            this.itColorFondo.Size = new System.Drawing.Size(271, 26);
            this.itColorFondo.Text = "Color de Fondo";
            this.itColorFondo.Click += new System.EventHandler(this.itColorFondo_Click);
            // 
            // toolStripMenuItem6
            // 
            this.toolStripMenuItem6.Name = "toolStripMenuItem6";
            this.toolStripMenuItem6.Size = new System.Drawing.Size(268, 6);
            // 
            // itMargenes
            // 
            this.itMargenes.Image = global::_06Editor.Properties.Resources.arrow_Sync_16xLG;
            this.itMargenes.Name = "itMargenes";
            this.itMargenes.Size = new System.Drawing.Size(271, 26);
            this.itMargenes.Text = "Márgenes";
            this.itMargenes.Click += new System.EventHandler(this.itMargenes_Click);
            // 
            // itAlineaciones
            // 
            this.itAlineaciones.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.itIzq,
            this.itCentrado,
            this.itDer});
            this.itAlineaciones.Name = "itAlineaciones";
            this.itAlineaciones.Size = new System.Drawing.Size(271, 26);
            this.itAlineaciones.Text = "Alineaciones";
            // 
            // itIzq
            // 
            this.itIzq.Image = global::_06Editor.Properties.Resources.lines_Text_left_justify_16xLG;
            this.itIzq.Name = "itIzq";
            this.itIzq.Size = new System.Drawing.Size(154, 26);
            this.itIzq.Text = "Izquierda";
            this.itIzq.Click += new System.EventHandler(this.TsbIzq_Click);
            // 
            // itCentrado
            // 
            this.itCentrado.Image = global::_06Editor.Properties.Resources.lines_Text_centered_16xLG;
            this.itCentrado.Name = "itCentrado";
            this.itCentrado.Size = new System.Drawing.Size(154, 26);
            this.itCentrado.Text = "Centrado";
            this.itCentrado.Click += new System.EventHandler(this.TsbCentrado_Click);
            // 
            // itDer
            // 
            this.itDer.Image = global::_06Editor.Properties.Resources.lines_Text_right_justify_16xLG;
            this.itDer.Name = "itDer";
            this.itDer.Size = new System.Drawing.Size(154, 26);
            this.itDer.Text = "Derecha";
            this.itDer.Click += new System.EventHandler(this.TsbDer_Click);
            // 
            // toolStripMenuItem7
            // 
            this.toolStripMenuItem7.Name = "toolStripMenuItem7";
            this.toolStripMenuItem7.Size = new System.Drawing.Size(268, 6);
            // 
            // itVinyetas
            // 
            this.itVinyetas.Name = "itVinyetas";
            this.itVinyetas.Size = new System.Drawing.Size(271, 26);
            this.itVinyetas.Text = "Viñetas";
            // 
            // itFormatoPagina
            // 
            this.itFormatoPagina.Name = "itFormatoPagina";
            this.itFormatoPagina.Size = new System.Drawing.Size(271, 26);
            this.itFormatoPagina.Text = "Formato de Página";
            this.itFormatoPagina.Click += new System.EventHandler(this.itFormatoPagina_Click);
            // 
            // toolStripMenuItem8
            // 
            this.toolStripMenuItem8.Name = "toolStripMenuItem8";
            this.toolStripMenuItem8.Size = new System.Drawing.Size(268, 6);
            // 
            // itQuitarFormatos
            // 
            this.itQuitarFormatos.Image = global::_06Editor.Properties.Resources.QuitarFormatos;
            this.itQuitarFormatos.Name = "itQuitarFormatos";
            this.itQuitarFormatos.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Delete)));
            this.itQuitarFormatos.Size = new System.Drawing.Size(271, 26);
            this.itQuitarFormatos.Text = "Quitar Formatos";
            this.itQuitarFormatos.Click += new System.EventHandler(this.itQuitarFormatos_Click);
            // 
            // verToolStripMenuItem
            // 
            this.verToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.itBarraHerEstandar,
            this.itBarraHerFormato,
            this.itBarraEstado});
            this.verToolStripMenuItem.Name = "verToolStripMenuItem";
            this.verToolStripMenuItem.Size = new System.Drawing.Size(44, 24);
            this.verToolStripMenuItem.Text = "Ver";
            // 
            // itBarraHerEstandar
            // 
            this.itBarraHerEstandar.Checked = true;
            this.itBarraHerEstandar.CheckState = System.Windows.Forms.CheckState.Checked;
            this.itBarraHerEstandar.Name = "itBarraHerEstandar";
            this.itBarraHerEstandar.Size = new System.Drawing.Size(299, 26);
            this.itBarraHerEstandar.Text = "Barra de herramientas Estandar";
            this.itBarraHerEstandar.Click += new System.EventHandler(this.itBarraHerEstandar_Click);
            // 
            // itBarraHerFormato
            // 
            this.itBarraHerFormato.Checked = true;
            this.itBarraHerFormato.CheckState = System.Windows.Forms.CheckState.Checked;
            this.itBarraHerFormato.Name = "itBarraHerFormato";
            this.itBarraHerFormato.Size = new System.Drawing.Size(299, 26);
            this.itBarraHerFormato.Text = "Barra de herramientas Formato";
            this.itBarraHerFormato.Click += new System.EventHandler(this.itBarraHerFormato_Click);
            // 
            // itBarraEstado
            // 
            this.itBarraEstado.Checked = true;
            this.itBarraEstado.CheckState = System.Windows.Forms.CheckState.Checked;
            this.itBarraEstado.Name = "itBarraEstado";
            this.itBarraEstado.Size = new System.Drawing.Size(299, 26);
            this.itBarraEstado.Text = "Barra de Estado";
            this.itBarraEstado.Click += new System.EventHandler(this.itBarraEstado_Click);
            // 
            // ayudaToolStripMenuItem
            // 
            this.ayudaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.itAcercaDe,
            this.itIndiceAyuda,
            this.itAyudaGeneral});
            this.ayudaToolStripMenuItem.Name = "ayudaToolStripMenuItem";
            this.ayudaToolStripMenuItem.Size = new System.Drawing.Size(65, 24);
            this.ayudaToolStripMenuItem.Text = "Ayuda";
            // 
            // itAcercaDe
            // 
            this.itAcercaDe.Name = "itAcercaDe";
            this.itAcercaDe.Size = new System.Drawing.Size(224, 26);
            this.itAcercaDe.Text = "Acerca de";
            this.itAcercaDe.Click += new System.EventHandler(this.itAcercaDe_Click);
            // 
            // itIndiceAyuda
            // 
            this.itIndiceAyuda.Name = "itIndiceAyuda";
            this.itIndiceAyuda.Size = new System.Drawing.Size(189, 26);
            this.itIndiceAyuda.Text = "Índice Ayuda";
            // 
            // itAyudaGeneral
            // 
            this.itAyudaGeneral.Name = "itAyudaGeneral";
            this.itAyudaGeneral.Size = new System.Drawing.Size(189, 26);
            this.itAyudaGeneral.Text = "Ayuda General";
            // 
            // rtbEditor
            // 
            this.rtbEditor.ContextMenuStrip = this.cmnEditor;
            this.rtbEditor.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rtbEditor.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtbEditor.Location = new System.Drawing.Point(0, 92);
            this.rtbEditor.Name = "rtbEditor";
            this.rtbEditor.Size = new System.Drawing.Size(1068, 414);
            this.rtbEditor.TabIndex = 2;
            this.rtbEditor.Text = "";
            this.rtbEditor.SelectionChanged += new System.EventHandler(this.rtbEditor_SelectionChanged);
            this.rtbEditor.MouseDown += new System.Windows.Forms.MouseEventHandler(this.rtbEditor_MouseDown);
            // 
            // cmnEditor
            // 
            this.cmnEditor.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.cmnEditor.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cmnDeshacer,
            this.cmnRehacer,
            this.toolStripSeparator4,
            this.cmnCortar,
            this.cmnCopiar,
            this.cmnPegar,
            this.toolStripSeparator5,
            this.cmnBorrar,
            this.cmnSeleccionarTodo});
            this.cmnEditor.Name = "cmnEditor";
            this.cmnEditor.Size = new System.Drawing.Size(197, 198);
            // 
            // cmnDeshacer
            // 
            this.cmnDeshacer.Image = global::_06Editor.Properties.Resources.Arrow_UndoRevertRestore_16xLG_color;
            this.cmnDeshacer.Name = "cmnDeshacer";
            this.cmnDeshacer.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Z)));
            this.cmnDeshacer.Size = new System.Drawing.Size(196, 26);
            this.cmnDeshacer.Text = "Deshacer";
            this.cmnDeshacer.Click += new System.EventHandler(this.tsbDeshacer_Click);
            // 
            // cmnRehacer
            // 
            this.cmnRehacer.Image = global::_06Editor.Properties.Resources.Arrow_RedoRetry_16xLG_color;
            this.cmnRehacer.Name = "cmnRehacer";
            this.cmnRehacer.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Y)));
            this.cmnRehacer.Size = new System.Drawing.Size(196, 26);
            this.cmnRehacer.Text = "Rehacer";
            this.cmnRehacer.Click += new System.EventHandler(this.tsbRehacer_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(193, 6);
            // 
            // cmnCortar
            // 
            this.cmnCortar.Image = global::_06Editor.Properties.Resources.cut;
            this.cmnCortar.Name = "cmnCortar";
            this.cmnCortar.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.X)));
            this.cmnCortar.Size = new System.Drawing.Size(196, 26);
            this.cmnCortar.Text = "Cortar";
            this.cmnCortar.Click += new System.EventHandler(this.tsbCortar_Click);
            // 
            // cmnCopiar
            // 
            this.cmnCopiar.Image = global::_06Editor.Properties.Resources.copy;
            this.cmnCopiar.Name = "cmnCopiar";
            this.cmnCopiar.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.C)));
            this.cmnCopiar.Size = new System.Drawing.Size(196, 26);
            this.cmnCopiar.Text = "Copiar";
            this.cmnCopiar.Click += new System.EventHandler(this.tsbCopiar_Click);
            // 
            // cmnPegar
            // 
            this.cmnPegar.Image = global::_06Editor.Properties.Resources.Paste;
            this.cmnPegar.Name = "cmnPegar";
            this.cmnPegar.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.V)));
            this.cmnPegar.Size = new System.Drawing.Size(196, 26);
            this.cmnPegar.Text = "Pegar";
            this.cmnPegar.Click += new System.EventHandler(this.tsbPegar_Click);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(193, 6);
            // 
            // cmnBorrar
            // 
            this.cmnBorrar.Name = "cmnBorrar";
            this.cmnBorrar.ShortcutKeys = System.Windows.Forms.Keys.Delete;
            this.cmnBorrar.Size = new System.Drawing.Size(196, 26);
            this.cmnBorrar.Text = "Borrar";
            this.cmnBorrar.Click += new System.EventHandler(this.itBorrar_Click);
            // 
            // cmnSeleccionarTodo
            // 
            this.cmnSeleccionarTodo.Name = "cmnSeleccionarTodo";
            this.cmnSeleccionarTodo.Size = new System.Drawing.Size(196, 26);
            this.cmnSeleccionarTodo.Text = "Seleccionar Todo";
            this.cmnSeleccionarTodo.Click += new System.EventHandler(this.itSeleccionarTodo_Click);
            // 
            // timerEditor
            // 
            this.timerEditor.Enabled = true;
            this.timerEditor.Interval = 1000;
            this.timerEditor.Tick += new System.EventHandler(this.TimerEditor_Tick);
            // 
            // dlgGuardar
            // 
            this.dlgGuardar.DefaultExt = "rtf";
            this.dlgGuardar.Filter = "Archivo de texto (.txt)|*.txt|Archivo Rico (.rtf)|*.rtf|Todos los Archivos (*.*)|" +
    "*.*";
            this.dlgGuardar.FilterIndex = 2;
            this.dlgGuardar.InitialDirectory = ".";
            this.dlgGuardar.Title = "Guardar Como";
            // 
            // dlgAbrir
            // 
            this.dlgAbrir.DefaultExt = "rtf";
            this.dlgAbrir.Filter = "Archivo de texto (.txt)|*.txt|Archivo Rico (.rtf)|*.rtf|Todos los Archivos (*.*)|" +
    "*.*";
            this.dlgAbrir.InitialDirectory = ".";
            this.dlgAbrir.Title = "Abrir Documento";
            // 
            // dlgImprimir
            // 
            this.dlgImprimir.AllowSomePages = true;
            this.dlgImprimir.ShowHelp = true;
            this.dlgImprimir.UseEXDialog = true;
            // 
            // dlgColores
            // 
            this.dlgColores.AnyColor = true;
            // 
            // fmEditor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1068, 536);
            this.Controls.Add(this.rtbEditor);
            this.Controls.Add(this.stEstadoEditor);
            this.Controls.Add(this.tsBarraFormato);
            this.Controls.Add(this.tsBarraEstandar);
            this.Controls.Add(this.mnEditor);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.mnEditor;
            this.Name = "fmEditor";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Editor";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.fmEditor_FormClosing);
            this.Load += new System.EventHandler(this.FmEditor_Load);
            this.Resize += new System.EventHandler(this.FmEditor_Resize);
            this.tsBarraEstandar.ResumeLayout(false);
            this.tsBarraEstandar.PerformLayout();
            this.cmnBarras.ResumeLayout(false);
            this.tsBarraFormato.ResumeLayout(false);
            this.tsBarraFormato.PerformLayout();
            this.stEstadoEditor.ResumeLayout(false);
            this.stEstadoEditor.PerformLayout();
            this.mnEditor.ResumeLayout(false);
            this.mnEditor.PerformLayout();
            this.cmnEditor.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip tsBarraEstandar;
        private System.Windows.Forms.ToolStrip tsBarraFormato;
        private System.Windows.Forms.StatusStrip stEstadoEditor;
        private System.Windows.Forms.MenuStrip mnEditor;
        private System.Windows.Forms.RichTextBox rtbEditor;
        private System.Windows.Forms.ToolStripButton tsbNuevo;
        private System.Windows.Forms.ToolStripButton tsbAbrir;
        private System.Windows.Forms.ToolStripButton tsbGuardar;
        private System.Windows.Forms.ToolStripButton tsbImprimir;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton tsbCortar;
        private System.Windows.Forms.ToolStripButton tsbCopiar;
        private System.Windows.Forms.ToolStripButton tsbPegar;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton tsbDeshacer;
        private System.Windows.Forms.ToolStripButton tsbRehacer;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripButton tsbCopiarFormato;
        private System.Windows.Forms.ToolStripButton tsbQuitarFormato;
        private System.Windows.Forms.ToolStripButton tsbNegrita;
        private System.Windows.Forms.ToolStripButton tsbCursiva;
        private System.Windows.Forms.ToolStripButton tsbSubrayado;
        private System.Windows.Forms.ToolStripButton tsbTachado;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripButton tsbIzq;
        private System.Windows.Forms.ToolStripButton tsbCentrado;
        private System.Windows.Forms.ToolStripButton tsbDer;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
        private System.Windows.Forms.ToolStripComboBox cbxFuente;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator8;
        private System.Windows.Forms.ToolStripComboBox cbxTamanyo;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator9;
        private System.Windows.Forms.ToolStripButton tsbColores;
        private System.Windows.Forms.ToolStripMenuItem archivoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem itNuevo;
        private System.Windows.Forms.ToolStripMenuItem itAbrir;
        private System.Windows.Forms.ToolStripMenuItem itGuardar;
        private System.Windows.Forms.ToolStripMenuItem itGuardarComo;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem itImprimir;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem itSalir;
        private System.Windows.Forms.ToolStripMenuItem ediciónToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem itDeshacer;
        private System.Windows.Forms.ToolStripMenuItem itRehacer;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem itCortar;
        private System.Windows.Forms.ToolStripMenuItem itCopiar;
        private System.Windows.Forms.ToolStripMenuItem itPegar;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem itBorrar;
        private System.Windows.Forms.ToolStripMenuItem itSeleccionarTodo;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem itIrA;
        private System.Windows.Forms.ToolStripMenuItem formatoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem itFuentes;
        private System.Windows.Forms.ToolStripMenuItem itColorFondo;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem itMargenes;
        private System.Windows.Forms.ToolStripMenuItem itAlineaciones;
        private System.Windows.Forms.ToolStripMenuItem itIzq;
        private System.Windows.Forms.ToolStripMenuItem itCentrado;
        private System.Windows.Forms.ToolStripMenuItem itDer;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem7;
        private System.Windows.Forms.ToolStripMenuItem itVinyetas;
        private System.Windows.Forms.ToolStripMenuItem itFormatoPagina;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem8;
        private System.Windows.Forms.ToolStripMenuItem itQuitarFormatos;
        private System.Windows.Forms.ToolStripMenuItem verToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem itBarraHerEstandar;
        private System.Windows.Forms.ToolStripMenuItem itBarraHerFormato;
        private System.Windows.Forms.ToolStripMenuItem itBarraEstado;
        private System.Windows.Forms.ToolStripMenuItem ayudaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem itAcercaDe;
        private System.Windows.Forms.ToolStripMenuItem itIndiceAyuda;
        private System.Windows.Forms.ToolStripMenuItem itAyudaGeneral;
        private System.Windows.Forms.ToolStripStatusLabel sl1;
        private System.Windows.Forms.ToolStripStatusLabel sl2;
        private System.Windows.Forms.ToolStripStatusLabel sl3;
        private System.Windows.Forms.ToolStripStatusLabel sl4;
        private System.Windows.Forms.ToolStripStatusLabel sl5;
        public System.Windows.Forms.Timer timerEditor;
        private System.Windows.Forms.SaveFileDialog dlgGuardar;
        private System.Windows.Forms.OpenFileDialog dlgAbrir;
        private System.Windows.Forms.PrintDialog dlgImprimir;
        private System.Windows.Forms.ColorDialog dlgColores;
        private System.Windows.Forms.FontDialog dlgFuentes;
        private System.Windows.Forms.ContextMenuStrip cmnBarras;
        private System.Windows.Forms.ToolStripMenuItem itcBarraEstandar;
        private System.Windows.Forms.ToolStripMenuItem itcBarraFormato;
        private System.Windows.Forms.ToolStripMenuItem itcBarraEstado;
        private System.Windows.Forms.ContextMenuStrip cmnEditor;
        private System.Windows.Forms.ToolStripMenuItem cmnDeshacer;
        private System.Windows.Forms.ToolStripMenuItem cmnRehacer;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripMenuItem cmnCortar;
        private System.Windows.Forms.ToolStripMenuItem cmnCopiar;
        private System.Windows.Forms.ToolStripMenuItem cmnPegar;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripMenuItem cmnBorrar;
        private System.Windows.Forms.ToolStripMenuItem cmnSeleccionarTodo;
    }
}

